"""EOF V1 Constants used throughout all tests."""

EOFCREATE_FAILURE = 0
