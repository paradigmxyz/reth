"""
abstract: Test cases for
[EIP-7873: TXCREATE and InitcodeTransaction](https://eips.ethereum.org/EIPS/eip-7873).
"""  # noqa: E501
