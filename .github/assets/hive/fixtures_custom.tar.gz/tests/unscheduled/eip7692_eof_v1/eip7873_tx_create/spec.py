"""EOF V1 Constants used throughout all tests."""

TXCREATE_FAILURE = 0
