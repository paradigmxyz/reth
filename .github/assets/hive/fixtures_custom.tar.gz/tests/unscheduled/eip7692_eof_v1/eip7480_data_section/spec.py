"""EOF V1 Constants used throughout all tests."""
