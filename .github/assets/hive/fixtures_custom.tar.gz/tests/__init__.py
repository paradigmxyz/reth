"""
Cross-client test cases organized by fork. Each directory underneath `tests/`
contains test cases corresponding [to the fork](https://ethereum.org/en/history)
in which the functionality-under-test was introduced.
"""
