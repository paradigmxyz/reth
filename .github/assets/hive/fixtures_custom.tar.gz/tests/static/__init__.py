"""Static State Tests Fillers from ethereum/tests repo."""

REFERENCE_SPEC_GIT_PATH = ""
REFERENCE_SPEC_VERSION = ""
