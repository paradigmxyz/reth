# Static State Tests

This directory contains static state test files that were originally located at [GeneralStateTestsFiller](https://github.com/ethereum/tests/tree/7dc757ec132e372b6178a016b91f4c639f366c02/src/GeneralStateTestsFiller).
