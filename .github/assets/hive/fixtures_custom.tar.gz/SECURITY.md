# Security Policy

## Reporting a Vulnerability

- **Please do not create a PR with a vulnerability visible.**

- **Please do not file a public ticket mentioning the vulnerability.**

To find out how to disclose a vulnerability in Ethereum visit [https://bounty.ethereum.org](https://bounty.ethereum.org) or email bounty@ethereum.org.
